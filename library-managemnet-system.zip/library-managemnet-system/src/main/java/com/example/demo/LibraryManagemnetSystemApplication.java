package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagemnetSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagemnetSystemApplication.class, args);
	}

}
